# 请用 PyTorch，写出一个最简单的 Transformer 代码示例，请包括训练集和测试集的划分。在训练集训练后，打印出获得的模型参数的值。最后在测试集上进行测试，给出测试结果，并画图展示结果

# 下面是一个使用 PyTorch 实现最简单的 Transformer 模型的代码示例，包括数据集的生成与划分、模型训练、测试集上的预测与评估，以及可视化结果。

# 在此代码中，我们将使用 PyTorch 提供的 `torch.nn.Transformer` 模块。模型的输入为序列数据，标签为序列元素的总和。

### 使用 PyTorch Transformer 的代码示例：

### 代码解析：
# 1. **数据生成**：
#    - 使用 `create_data()` 函数生成随机序列数据，每个序列的长度为 10，特征维度为 16，标签为序列元素的和。

# 2. **Transformer 模型**：
#    - `TransformerModel` 类实现了一个最简单的 Transformer 模型，包含一个编码器层（`nn.TransformerEncoderLayer`）和一个解码层（`Linear`），用于将序列嵌入后的表示转换为回归输出。
#    - 编码器通过 `nn.TransformerEncoder` 堆叠多个编码层，处理序列中的信息。
#    - 最后，经过编码器的输出将展平成向量，传入线性层得到最终预测结果。

# 3. **训练**：
#    - 训练过程中，使用 Adam 优化器，损失函数为均方误差 (`MSELoss`)。
#    - 每 100 个 Epoch 打印一次损失值，以便观察训练过程。

# 4. **模型参数**：
#    - 打印 Transformer 编码器层的可训练参数，以便了解模型权重。

# 5. **测试与评估**：
#    - 在测试集上进行预测，并计算均方误差（`MSE`）作为评估指标。
#    - 使用 `matplotlib` 绘制测试集中预测值与真实值的对比图。

# ### 结果展示：
# 1. **模型权重**：打印 Transformer 模型中的编码器层和解码层的权重矩阵。
# 2. **预测结果**：使用均方误差（MSE）评估模型在测试集上的表现。
# 3. **可视化**：展示测试集中真实值与预测值的对比图，观察模型的预测精度。

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# 生成简单的序列数据
def create_data(n_samples=1000, seq_len=10, embed_dim=16):
    X = np.random.randn(n_samples, seq_len, embed_dim)  # 随机序列
    y = np.sum(X, axis=(1, 2))  # 标签为序列元素的和
    return X, y

# 定义 Transformer 模型
class TransformerModel(nn.Module):
    def __init__(self, embed_dim, n_heads, num_encoder_layers, num_decoder_layers, seq_len):
        super(TransformerModel, self).__init__()
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=num_encoder_layers)
        self.decoder_layer = nn.Linear(seq_len * embed_dim, 1)  # 最后将序列展开为向量并回归输出
        
    def forward(self, x):
        x = self.transformer_encoder(x)
        x = x.flatten(start_dim=1)  # 展平
        output = self.decoder_layer(x)
        return output

# 生成数据集
seq_len = 10
embed_dim = 16
X, y = create_data(n_samples=1000, seq_len=seq_len, embed_dim=embed_dim)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为 PyTorch 张量
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32).reshape(-1, 1)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32).reshape(-1, 1)

# 定义模型、损失函数和优化器
n_heads = 4
num_encoder_layers = 2
num_decoder_layers = 1
model = TransformerModel(embed_dim=embed_dim, n_heads=n_heads, num_encoder_layers=num_encoder_layers, num_decoder_layers=num_decoder_layers, seq_len=seq_len)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
n_epochs = 500
for epoch in range(n_epochs):
    model.train()
    
    # 前向传播
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    
    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # 打印损失
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{n_epochs}], Loss: {loss.item():.4f}')

# 打印模型的参数
print("\n模型的 Transformer 编码器层权重:")
for name, param in model.named_parameters():
    if param.requires_grad:
        print(name, param.data)

# 在测试集上进行预测
model.eval()
with torch.no_grad():
    y_test_pred = model(X_test).numpy()

# 评估测试结果
mse = mean_squared_error(y_test, y_test_pred)
print(f"\n测试集上的均方误差 (MSE): {mse:.4f}")

# 可视化测试集的预测与真实值
def plot_predictions(y_true, y_pred):
    plt.figure(figsize=(8, 4))
    plt.plot(y_true, label='True Values')
    plt.plot(y_pred, label='Predicted Values')
    plt.legend()
    plt.title('True vs Predicted Values')
    plt.xlabel('Test Sample Index')
    plt.ylabel('Value')
    plt.show()

# 绘制测试集的预测结果
plot_predictions(y_test.numpy(), y_test_pred)
