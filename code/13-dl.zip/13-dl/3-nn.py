import torch
import torch.nn as nn
import torch.optim as optim

# 创建数据集
# 假设有两个特征和两个类别
# 生成100个样本，每个样本有两个特征
# 每个样本属于三个类别之一
torch.manual_seed(42)  # 设置随机种子，以便结果可重复
num_samples = 6
num_features = 2
num_classes = 2
# X = torch.randn(num_samples, num_features)
X = [[1,1],[1,2],[2,1],[5,4],[4,5],[5,6]]
y = [1,1,1,0,0,0]
X = torch.tensor(X, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.long)
# y = torch.randint(0, num_classes, (num_samples,))

# 定义神经元网络模型
class NeuralNetwork(nn.Module):
    def __init__(self, input_size, output_size):
        super(NeuralNetwork, self).__init__()
        self.linear = nn.Linear(input_size, output_size)

    def forward(self, x):
        return self.linear(x)

# 创建模型实例
model = NeuralNetwork(num_features, num_classes)

# 定义损失函数
criterion = nn.CrossEntropyLoss()

# 定义优化器
optimizer = optim.SGD(model.parameters(), lr=0.1)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    # 前向传播
    outputs = model(X)
    softmax = nn.Softmax(dim=1)
    probs = softmax(outputs)
    predicted = softmax(outputs).argmax(dim=1)

    # 计算损失
    loss = criterion(probs, y)

    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if (epoch+1) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 使用训练好的模型进行预测
with torch.no_grad():
    outputs = model(X)
    softmax = nn.Softmax(dim=1)
    predicted = softmax(outputs).argmax(dim=1)

# 计算准确率
accuracy = (predicted == y).sum().item() / num_samples
print('Accuracy: {:.2f}%'.format(accuracy * 100))