import torch
import torch.nn as nn

# 定义输入张量（batch_size, channels, height, width）
input_tensor = torch.randn(1, 2, 5, 5)  # 假设输入大小为1个batch，3个通道，高度和宽度为32像素

# 定义卷积层
# 输入通道数为3，输出通道数为6，卷积核大小为3x3，步长为1，填充为0
conv_layer = nn.Conv2d(in_channels=2, out_channels=3, kernel_size=2, stride=1, padding=0)

print(conv_layer.weight.data)
print(conv_layer.bias.data)

# 前向传播
output_tensor = conv_layer(input_tensor)

# 输出卷积结果的形状
print("Output tensor shape:", output_tensor.shape)
print(output_tensor)