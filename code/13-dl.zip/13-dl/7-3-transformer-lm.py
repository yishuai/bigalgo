# 请用 PyTorch，写出一个最简单的基于 Transformer 的语言模型代码示例，请包括训练集和测试集的划分。在训练集训练后，打印出获得的模型参数的值。最后在测试集上进行测试，给出测试结果，并画图展示结果

# 下面是一个基于 PyTorch 的最简单 Transformer 语言模型（LM）实现。这个模型的任务是基于给定的输入序列预测下一个单词。我们将包括训练集和测试集的划分、模型训练过程、模型参数的打印、测试集上的评估结果和可视化。

### 使用 PyTorch Transformer 实现语言模型的代码示例：

### 代码解析：
# 1. **数据生成**：
#    - `create_text_data()` 函数生成随机的单词序列数据，其中每个单词是从词汇表中随机选择的，目标是预测序列中的下一个单词。

# 2. **Transformer 语言模型**：
#    - `TransformerLM` 类实现了一个基于 Transformer 编码器的语言模型。
#    - 词嵌入层将输入单词转换为嵌入向量，位置编码模块为序列中的单词位置增加位置信息。
#    - Transformer 编码器模块处理序列，并使用全连接层预测下一个单词的概率分布。

# 3. **训练**：
#    - 使用 Adam 优化器和交叉熵损失函数进行训练。每 50 个 Epoch 打印一次损失值。

# 4. **模型参数**：
#    - 打印 Transformer 编码器层的可训练参数，以了解模型权重。

# 5. **测试与评估**：
#    - 在测试集上进行预测，并计算准确率（`Accuracy`）作为评估指标。
#    - 使用 `matplotlib` 可视化部分测试样本的真实值和预测值。

# ### 结果展示：
# 1. **模型权重**：打印 Transformer 模型中的编码器层权重。
# 2. **评估结果**：通过准确率评估模型在测试集上的表现。
# 3. **可视化**：展示测试集中部分样本的真实值与预测值，观察模型的预测效果。

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 创建简单的文本数据
def create_text_data(vocab_size=20, seq_len=10, n_samples=1000):
    X = np.random.randint(0, vocab_size, (n_samples, seq_len))  # 随机生成单词序列
    y = np.roll(X, -1, axis=1)  # 目标是预测序列中的下一个词
    return X, y

# 定义 Transformer 语言模型
class TransformerLM(nn.Module):
    def __init__(self, vocab_size, embed_dim, n_heads, num_layers, seq_len):
        super(TransformerLM, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)  # 词嵌入层
        self.pos_encoder = PositionalEncoding(embed_dim, dropout=0.1, max_len=seq_len)
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc_out = nn.Linear(embed_dim, vocab_size)  # 输出层，预测下一个词的词概率分布

    def forward(self, x):
        x = self.embedding(x) * np.sqrt(x.size(-1))  # 缩放嵌入
        x = self.pos_encoder(x)
        x = self.transformer_encoder(x)
        output = self.fc_out(x)
        return output

# 定义位置编码
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

# 生成数据集
vocab_size = 20  # 词汇量大小
seq_len = 10  # 序列长度
X, y = create_text_data(vocab_size=vocab_size, seq_len=seq_len, n_samples=1000)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为 PyTorch 张量
X_train = torch.tensor(X_train, dtype=torch.long)
y_train = torch.tensor(y_train, dtype=torch.long)
X_test = torch.tensor(X_test, dtype=torch.long)
y_test = torch.tensor(y_test, dtype=torch.long)

# 定义模型、损失函数和优化器
embed_dim = 16
n_heads = 2
num_layers = 2
model = TransformerLM(vocab_size=vocab_size, embed_dim=embed_dim, n_heads=n_heads, num_layers=num_layers, seq_len=seq_len)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
n_epochs = 200
for epoch in range(n_epochs):
    model.train()
    
    optimizer.zero_grad()
    outputs = model(X_train).permute(0, 2, 1)  # 输出需要 permute 以匹配 CrossEntropyLoss 的输入
    loss = criterion(outputs, y_train)
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 50 == 0:
        print(f'Epoch [{epoch + 1}/{n_epochs}], Loss: {loss.item():.4f}')

# 打印模型的参数
print("\n模型的 Transformer 编码器层权重:")
for name, param in model.named_parameters():
    if param.requires_grad:
        print(name, param.data)

# 在测试集上进行预测
model.eval()
with torch.no_grad():
    y_test_pred = model(X_test)
    y_test_pred = y_test_pred.argmax(dim=-1)  # 取最大概率的词作为预测词

# 评估测试结果
accuracy = accuracy_score(y_test.flatten(), y_test_pred.flatten())
print(f"\n测试集上的准确率 (Accuracy): {accuracy:.4f}")

# 可视化测试集的预测与真实值
def plot_predictions(y_true, y_pred, n_samples=10):
    plt.figure(figsize=(10, 4))
    for i in range(n_samples):
        plt.subplot(2, 5, i+1)
        plt.plot(y_true[i], label='True')
        plt.plot(y_pred[i], label='Predicted')
        plt.legend()
        plt.title(f'Sample {i}')
    plt.tight_layout()
    plt.show()

# 绘制测试集的部分预测结果
plot_predictions(y_test.numpy(), y_test_pred.numpy(), n_samples=10)
