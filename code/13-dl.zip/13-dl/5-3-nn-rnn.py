import torch
import torch.nn as nn
import numpy as np

# 设置随机种子，以便结果可重复
torch.manual_seed(42)

# 定义RNN模型
class RNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(RNN, self).__init__()
        self.hidden_size = hidden_size
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, hidden):
        out, hidden = self.rnn(x, hidden)
        out = self.fc(out)
        return out, hidden

# 定义基因序列生成函数
def generate_gene_sequence(model, input_size, hidden_size, output_size, sequence_length):
    # 初始化隐藏状态和输入
    hidden = torch.zeros(1, 1, hidden_size)
    input = torch.randn(1, sequence_length, input_size)
    gene_sequence = []

    # 使用模型生成基因序列
    for i in range(sequence_length):
        output, hidden = model(input[:, i:i+1, :], hidden)
        gene_sequence.append(output.squeeze().argmax().item())

    return gene_sequence

# 设置模型参数
input_size = 1  # 输入特征维度
hidden_size = 2  # 隐藏状态维度
output_size = 2  # 输出特征维度（与输入相同）
sequence_length = 4  # 生成序列的长度

# 创建RNN模型实例
model = RNN(input_size, hidden_size, output_size)

# 打印RNN模型的参数
print("RNN model parameters:")
for name, param in model.state_dict().items():
    print(name, param.shape)
    print(name, param.data)

# 生成基因序列
gene_sequence = generate_gene_sequence(model, input_size, hidden_size, output_size, sequence_length)
print("Generated gene sequence:", gene_sequence)
