import torch
import torch.nn as nn

# 定义RNN模型
class SimpleRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleRNN, self).__init__()
        self.hidden_size = hidden_size
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, hidden):
        out, hidden = self.rnn(x, hidden)
        out = self.fc(out[:, -1, :])
        return out, hidden

# 创建示例数据
input_size = 1  # 输入特征维度
hidden_size = 2  # 隐藏状态维度
output_size = 1  # 输出特征维度

input_data = torch.tensor([[[0.1], [0.2], [0.3], [0.4]]])  # 示例输入数据
target_data = torch.tensor([[[0.2], [0.3], [0.4], [0.5]]])  # 示例目标数据

# 创建RNN模型实例
model = SimpleRNN(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    optimizer.zero_grad()
    hidden = torch.zeros(1, input_data.size(0), hidden_size)
    output, hidden = model(input_data, hidden)
    loss = criterion(output, target_data)
    loss.backward()
    optimizer.step()

    if (epoch) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 测试模型
with torch.no_grad():
    hidden = torch.zeros(1, input_data.size(0), hidden_size)
    output, _ = model(input_data, hidden)
    print("Predicted output:", output)
