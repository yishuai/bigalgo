# 请问 torch 有可以直接调用的 attention 模块吗？

# 是的，PyTorch 提供了可以直接调用的 Attention 模块。在 PyTorch 中，最常见的 Attention 模块是 `torch.nn.MultiheadAttention`，它实现了多头自注意力机制（Multi-head Self-Attention），这是 Transformer 网络中的一个关键组件。

# ### `torch.nn.MultiheadAttention` 简单介绍：

# - `MultiheadAttention` 接受输入序列，并为每个位置计算其与其他位置的相关性（注意力权重），然后对这些相关性加权求和，产生新的序列表示。
# - 它支持多头机制，即可以并行计算多个独立的注意力机制（每个头表示不同的注意力模式），并将结果拼接起来。
# - 这个模块在序列建模任务（如 NLP 和时间序列分析）中非常常用。

# ### 参数解释：
# - **`embed_dim`**：输入序列中每个位置的特征维度（例如，嵌入向量的大小）。
# - **`num_heads`**：多头注意力的头数。多头的计算使模型能够同时关注序列中不同的部分。
# - **`batch_first=True`**：输入的第一个维度是 batch size，这样可以使输入维度为 `(batch_size, seq_len, embed_dim)`，而不是默认的 `(seq_len, batch_size, embed_dim)`。

# ### 输出：
# - **`attn_output`**：多头注意力的输出，它的形状与输入的 `query` 相同，即 `(batch_size, seq_len, embed_dim)`。
# - **`attn_weights`**：注意力权重矩阵，形状为 `(batch_size, num_heads, seq_len, seq_len)`，表示每个注意力头对于每个序列位置的注意力分布。

# ### 多头注意力机制的优势：
# - **并行处理**：多个头并行计算注意力，每个头可以关注输入序列的不同部分。
# - **更好的表示能力**：通过多头机制，模型能够学习到更加丰富的序列间的关系。

# 如果你想实现更复杂的 Attention 机制（例如基于特定需求的 Self-Attention），你也可以基于 `MultiheadAttention` 进一步构建复杂模型。

# ### `torch.nn.MultiheadAttention` 示例代码：

# 下面是一个简单的使用 `torch.nn.MultiheadAttention` 的代码示例。

import torch
import torch.nn as nn
import numpy as np

# 定义序列长度、特征维度和多头数量
seq_len = 10
embed_dim = 16  # 输入特征的维度
num_heads = 4   # 注意力头的数量

# 生成一些示例输入数据 (batch_size, seq_len, embed_dim)
x = torch.rand(5, seq_len, embed_dim)  # 5个样本，每个样本有长度为10的序列，特征维度为16

# 定义 MultiheadAttention 模块
attention = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads, batch_first=True)

# MultiheadAttention 的输入是 (seq_len, batch_size, embed_dim)，因此我们需要调整输入维度
# 这里我们使用 batch_first=True 让输入直接按 (batch_size, seq_len, embed_dim) 传入

# Q, K, V 可以相同
query = x
key = x
value = x

# 计算多头注意力
attn_output, attn_weights = attention(query, key, value)

# 输出结果
print("注意力输出: ", attn_output.shape)  # 输出的形状应该是 (batch_size, seq_len, embed_dim)
print("注意力权重: ", attn_weights.shape)  # 权重的形状应该是 (batch_size, num_heads, seq_len, seq_len)
