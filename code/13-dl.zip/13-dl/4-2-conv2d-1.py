import torch
import torch.nn as nn

# 定义一个输入张量（1个样本，1个通道，5x像素）
input_tensor = torch.randn(1, 1, 5, 5)

x=[[[[7,2,3,3,8],[4,5,3,8,4],[3,3,2,8,4],[2,8,7,2,7],[5,4,4,5,4]]]]
input_tensor = torch.tensor(x, dtype=torch.float32)
# y_tensor = torch.tensor(y, dtype=torch.float32)

# 定义一个卷积层
# 输入通道数为1，输出通道数为1，卷积核大小为3x3，默认步长为1，默认填充为0
conv_layer = nn.Conv2d(1, 1, 3)

# 打印卷积核参数和偏置参数
print("Convolutional kernel parameters:")
print(conv_layer.weight)
print("Bias parameters:")
print(conv_layer.bias)

w = [[[[1, 0, -1], [1, 0, -1], [1, 0, -1]]]]
conv_layer.weight.data = torch.tensor(w, dtype=torch.float32)
conv_layer.bias.data = torch.tensor([0], dtype=torch.float32)

# 前向传播，应用卷积操作
output_tensor = conv_layer(input_tensor)

# 打印输出张量和卷积核参数
print("Output tensor shape:", output_tensor.shape)
print("Convolutional kernel parameters:", conv_layer.weight.shape)
print(output_tensor)