# 请用 PyTorch 的 MultiheadAttention，写出一个最简单的 Attention 代码示例，请包括训练集和测试集的划分。在训练集训练后，打印出获得的模型参数的值。最后在测试集上进行测试，给出测试的评估结果，并画图展示结果

# 下面是一个使用 PyTorch 的 `MultiheadAttention` 模块实现的最简单 Attention 示例，包括训练集和测试集的划分，模型训练后打印模型参数，测试集上的预测与评估，以及结果的可视化。

# 使用 `MultiheadAttention` 实现简单模型的示例：

# 代码解析：
# 1. **数据生成**：
#    - `create_data()` 函数生成随机序列数据，其中每个序列包含 10 个时间步，嵌入维度为 16，标签是每个序列元素之和。

# 2. **Attention 模型**：
#    - `AttentionModel` 类使用 `torch.nn.MultiheadAttention` 实现了多头注意力机制。
#    - 模型对输入序列进行 Attention 操作后，输出结果取平均值作为序列的表示，并通过一个全连接层进行预测。

# 3. **训练**：
#    - 使用 Adam 优化器进行训练，损失函数为均方误差 (`MSELoss`)。
#    - 训练过程中每隔 100 个 Epoch 打印一次损失值。

# 4. **模型参数**：
#    - 打印 `MultiheadAttention` 层的模型权重，方便了解 Attention 机制中的可训练参数。

# 5. **测试与评估**：
#    - 在测试集上进行预测，计算均方误差（`MSE`）作为评估指标。
#    - 使用 `matplotlib` 绘制 Attention 权重的热图，以及真实值与预测值的比较图。

# ### 结果展示：
# 1. **Attention 权重**：显示每个序列中每个时间步的注意力分布。
# 2. **预测值与真实值**：绘制测试集中预测值和真实值的对比图。
# 3. **评估指标**：均方误差（`MSE`）用于衡量模型的预测效果。

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# 生成简单的序列数据
def create_data(n_samples=1000, seq_len=10, embed_dim=16):
    X = np.random.randn(n_samples, seq_len, embed_dim)  # 随机序列
    y = np.sum(X, axis=(1, 2))  # 标签为序列元素的和
    return X, y

# 定义带 Attention 的模型
class AttentionModel(nn.Module):
    def __init__(self, embed_dim, num_heads):
        super(AttentionModel, self).__init__()
        self.multihead_attn = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads, batch_first=True)
        self.fc = nn.Linear(embed_dim, 1)  # 输出层
        
    def forward(self, x):
        attn_output, attn_weights = self.multihead_attn(x, x, x)
        # 将每个序列位置的输出取平均，得到整体的表示
        context = torch.mean(attn_output, dim=1)
        output = self.fc(context)
        return output, attn_weights

# 生成数据集
seq_len = 10
embed_dim = 16
X, y = create_data(n_samples=1000, seq_len=seq_len, embed_dim=embed_dim)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为 PyTorch 张量
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32).reshape(-1, 1)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32).reshape(-1, 1)

# 定义模型、损失函数和优化器
num_heads = 4
model = AttentionModel(embed_dim=embed_dim, num_heads=num_heads)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
n_epochs = 500
for epoch in range(n_epochs):
    model.train()
    
    # 前向传播
    outputs, _ = model(X_train)
    loss = criterion(outputs, y_train)
    
    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # 打印损失
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{n_epochs}], Loss: {loss.item():.4f}')

# 打印模型的注意力层参数
print("\n模型的 MultiheadAttention 层权重:")
for name, param in model.multihead_attn.named_parameters():
    if param.requires_grad:
        print(name, param.data)

# 在测试集上进行预测
model.eval()
with torch.no_grad():
    y_test_pred, attn_weights = model(X_test)
    y_test_pred = y_test_pred.numpy()

# 评估测试结果
mse = mean_squared_error(y_test, y_test_pred)
print(f"\n测试集上的均方误差 (MSE): {mse:.4f}")

# 可视化 Attention 权重
def plot_attention_weights(attn_weights, idx=0):
    plt.figure(figsize=(10, 2))
    plt.imshow(attn_weights[idx].numpy(), cmap='hot', aspect='auto')
    plt.colorbar()
    plt.title(f'Attention Weights for Test Sample {idx}')
    plt.xlabel('Sequence Length')
    plt.ylabel('Attention Heads')
    plt.show()

# 绘制测试集中第一个样本的 Attention 权重
plot_attention_weights(attn_weights, idx=0)

# 可视化测试集的预测与真实值
def plot_predictions(y_true, y_pred):
    plt.figure(figsize=(8, 4))
    plt.plot(y_true, label='True Values')
    plt.plot(y_pred, label='Predicted Values')
    plt.legend()
    plt.title('True vs Predicted Values')
    plt.xlabel('Test Sample Index')
    plt.ylabel('Value')
    plt.show()

# 绘制测试集的预测结果
plot_predictions(y_test.numpy(), y_test_pred)
