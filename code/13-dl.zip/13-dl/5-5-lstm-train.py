import torch
import torch.nn as nn
import torch.optim as optim

# 定义LSTM模型
class SimpleLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleLSTM, self).__init__()
        self.hidden_size = hidden_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, hidden):
        out, hidden = self.lstm(x, hidden)
        out = self.fc(out[:, -1, :])
        return out, hidden

# 创建示例数据
input_size = 1  # 输入特征维度
hidden_size = 2  # 隐藏状态维度
output_size = 1  # 输出特征维度

input_data = torch.tensor([[[0.1], [0.2], [0.3], [0.4]]])  # 示例输入数据
target_data = torch.tensor([[[0.2], [0.3], [0.4], [0.5]]])  # 示例目标数据

# 创建LSTM模型实例
model = SimpleLSTM(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    optimizer.zero_grad()
    hidden = (torch.zeros(1, input_data.size(0), hidden_size),  # 初始化隐藏状态
              torch.zeros(1, input_data.size(0), hidden_size))  # 初始化细胞状态
    output, _ = model(input_data, hidden)
    loss = criterion(output, target_data)
    loss.backward()
    optimizer.step()

    if (epoch) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 测试模型
with torch.no_grad():
    hidden = (torch.zeros(1, input_data.size(0), hidden_size),  # 初始化隐藏状态
              torch.zeros(1, input_data.size(0), hidden_size))  # 初始化细胞状态
    output, _ = model(input_data, hidden)
    print("Predicted output:", output)
    weight_ih = model.lstm.weight_ih_l0  # 输入到隐藏状态的权重
    weight_hh = model.lstm.weight_hh_l0  # 隐藏状态到隐藏状态的权重
    bias_ih = model.lstm.bias_ih_l0  # 输入到隐藏状态的偏置
    bias_hh = model.lstm.bias_hh_l0  # 隐藏状态到隐藏状态的偏置

    # 提取三个门的权重参数
    input_gate_weights = weight_ih[:, :hidden_size]
    forget_gate_weights = weight_ih[:, hidden_size:2*hidden_size]
    output_gate_weights = weight_ih[:, 2*hidden_size:3*hidden_size]

    # 打印权重参数
    print("Input gate weights:", input_gate_weights)
    print("Forget gate weights:", forget_gate_weights)
    print("Output gate weights:", output_gate_weights)