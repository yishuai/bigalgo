import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 定义Sequence to Sequence模型
class SimpleSeq2Seq(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SimpleSeq2Seq, self).__init__()
        self.encoder = nn.RNN(input_size, hidden_size, batch_first=True)
        self.decoder = nn.RNN(hidden_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, target=None):
        _, hidden = self.encoder(x)
        if target is not None:  # 使用teacher forcing
            input_forcing = torch.cat([torch.zeros(x.size(0), 1, x.size(2)), target_data[:, :-1, :]], dim=1)
            target_data_expanded = input_forcing.expand(-1, -1, 8)  # 在最后一个维度上重复扩展8次
            output, _ = self.decoder(target_data_expanded, hidden)
        else:  # 不使用teacher forcing
            output, _ = self.decoder(torch.zeros(x.size(0), x.size(1), hidden_size), hidden)
        output = self.fc(output)
        return output

# 创建示例数据
input_size = 1  # 输入特征维度
hidden_size = 8  # 隐藏状态维度
output_size = 1  # 输出特征维度

input_data = torch.tensor([[[0.1], [0.2], [0.3], [0.4]]])  # 示例输入数据
target_data = torch.tensor([[[0.2], [0.3], [0.4], [0.5]]])  # 示例目标数据


# 创建Sequence to Sequence模型实例
model = SimpleSeq2Seq(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    optimizer.zero_grad()
    output = model(input_data, target_data)  # 使用teacher forcing
    loss = criterion(output, target_data)
    loss.backward()
    optimizer.step()

    if (epoch+1) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 测试模型
with torch.no_grad():
    output = model(input_data)
    print("Predicted output:", output)
