
# 请用 PyTorch，写出一个最简单的 Attention 代码示例，请包括训练集和测试集的划分。在训练集训练后，打印出获得的模型参数的值。最后在测试集上进行测试，并画图展示结果

# ### 代码解析：
# 1. **数据生成**：
#    - 创建了随机的序列数据`X`，其标签为序列中所有值的和`y`。序列长度为10。
#    - 数据通过`train_test_split`划分为训练集和测试集。

# 2. **Attention 模型**：
#    - `SimpleAttention`类定义了一个简单的注意力机制模型。
#    - 模型首先计算每个输入位置的注意力权重，使用`Softmax`将权重归一化，然后对输入序列进行加权求和。
#    - 最后通过全连接层`fc`输出一个标量（回归任务）。

# 3. **训练过程**：
#    - 使用 Adam 优化器对模型进行训练，使用均方误差（`MSELoss`）作为损失函数。
#    - 每隔100个 Epoch 打印一次训练损失。

# 4. **模型参数**：
#    - 训练结束后，打印 Attention 层的权重矩阵。

# 5. **测试和可视化**：
#    - 在测试集上进行预测，并提取注意力权重。
#    - 使用`matplotlib`绘制某个测试样本的注意力权重热图。

# ### 结果：
# - **Attention 权重**将显示为热图，展示模型对每个序列元素的关注程度。
# - **模型参数**，即 Attention 层的权重矩阵将在终端输出。

# 下面是一个使用 PyTorch 实现的最简单的 Attention 机制的代码示例。Attention 机制通常用于处理序列数据，但在这个简单的例子中，我们将应用于生成一些合成的数据。代码包括训练集和测试集的划分，模型训练后参数的打印，测试集上的预测，以及绘制 Attention 权重的热图。

### PyTorch Attention 实现代码：

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# 创建一些简单的序列数据
def create_data(n_samples=1000, seq_len=10):
    X = np.random.randn(n_samples, seq_len, 1)  # 随机序列
    y = np.sum(X, axis=1)  # 标签为序列的和
    return X, y

# Attention 模型
class SimpleAttention(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(SimpleAttention, self).__init__()
        self.attention = nn.Linear(input_dim, hidden_dim)  # attention 权重
        self.softmax = nn.Softmax(dim=1)
        self.fc = nn.Linear(hidden_dim, 1)  # 输出层

    def forward(self, x):
        # Attention 分数计算
        attention_weights = self.attention(x)  # (batch_size, seq_len, hidden_dim)
        attention_weights = self.softmax(attention_weights)  # 归一化成概率

        # 加权求和
        context = torch.sum(attention_weights * x, dim=1)  # (batch_size, hidden_dim)
        output = self.fc(context)  # (batch_size, 1)

        return output, attention_weights

# 生成训练集和测试集
X, y = create_data(n_samples=1000, seq_len=10)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为 PyTorch 张量
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

# 定义模型、损失函数和优化器
input_dim = X_train.shape[2]
hidden_dim = 10
model = SimpleAttention(input_dim=input_dim, hidden_dim=hidden_dim)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# 训练模型
n_epochs = 1000
for epoch in range(n_epochs):
    model.train()
    
    # 前向传播
    outputs, _ = model(X_train)
    loss = criterion(outputs.squeeze(), y_train)
    
    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # 打印损失
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{n_epochs}], Loss: {loss.item():.4f}')

# 打印模型参数
print("\nAttention 层权重:")
for param in model.attention.parameters():
    print(param)

# 测试模型并绘制 Attention 权重
model.eval()
with torch.no_grad():
    y_test_pred, attention_weights = model(X_test)
    attention_weights = attention_weights.numpy()

# 可视化 Attention 权重
def plot_attention_weights(attention_weights, idx=0):
    plt.figure(figsize=(10, 2))
    plt.imshow(attention_weights[idx], cmap='hot', aspect='auto')
    plt.colorbar()
    plt.title(f'Attention Weights for Test Sample {idx}')
    plt.xlabel('Hidden Dimension')
    plt.ylabel('Sequence Length')
    plt.show()

# 绘制测试集第一个样本的 Attention 权重
plot_attention_weights(attention_weights, idx=0)