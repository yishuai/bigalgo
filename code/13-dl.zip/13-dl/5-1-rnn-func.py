import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

torch.manual_seed(1)

rnn = nn.RNN(3, 3)  # Input dim is 3, output dim is 3
inputs = [torch.randn(1, 3) for _ in range(5)]  # make a sequence of length 5

# 打印 RNN 模型参数
print("RNN model parameters:")
for name, param in rnn.state_dict().items():
    print(name, param.shape)
    print(name, param.data)

# 打印初始的RNN层权重参数
print("Initial RNN layer weight parameters:")
print("Input to hidden weight:", rnn.weight_ih_l0.data)
print("Hidden to hidden weight:", rnn.weight_hh_l0.data)

# 手动设置RNN层权重参数为随机值
w = [[1, 0, -1], [1, 0, -1], [1, 0, -1]]
rnn.weight_ih_l0.data = torch.tensor(w, dtype=torch.float32)
rnn.weight_hh_l0.data = torch.tensor(w, dtype=torch.float32)
rnn.bias_ih_l0.data = torch.tensor([0], dtype=torch.float32)
rnn.bias_hh_l0.data = torch.tensor([0], dtype=torch.float32)

# 打印设置后的RNN层权重参数
print("Updated RNN layer weight parameters:")
print("Input to hidden weight:", rnn.weight_ih_l0.data)
print("Hidden to hidden weight:", rnn.weight_hh_l0.data)

# initialize the hidden state.
hidden = (torch.randn(1, 1, 3))
for i in inputs:
    # Step through the sequence one element at a time.
    # after each step, hidden contains the hidden state.
    out, hidden = rnn(i.view(1, 1, -1), hidden)

# alternatively, we can do the entire sequence all at once.
# the first value returned by LSTM is all of the hidden states throughout
# the sequence. the second is just the most recent hidden state
# (compare the last slice of "out" with "hidden" below, they are the same)
# The reason for this is that:
# "out" will give you access to all hidden states in the sequence
# "hidden" will allow you to continue the sequence and backpropagate,
# by passing it as an argument  to the lstm at a later time
# Add the extra 2nd dimension
inputs = torch.cat(inputs).view(len(inputs), 1, -1)
hidden = (torch.randn(1, 1, 3))  # clean out hidden state
out, hidden = rnn(inputs, hidden)
print(out)
print(hidden)