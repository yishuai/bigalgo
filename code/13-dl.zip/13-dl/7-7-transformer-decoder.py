# GPT 4 Prompt：
# 上面的代码有问题：初始化生成的序列，不应该初始为输入序列吧？第一步，应该把解码器输入初始化为起始符 <start>，生成第一个词；然后，将生成的第一个词作为输入，继续生成下一个词；这个过程一直持续到生成终止符 <end>，或达到最大长度限制。是不是这样？如果是。请修改上面的代码

# 你说得完全正确。在自回归生成序列的过程中，模型不应该直接将输入序列用于生成，而应该按照以下步骤进行：

# 1. **初始化解码器输入**：解码器的初始输入是一个特殊的 `<start>` 标记。
# 2. **逐步生成词汇**：模型基于当前输入预测下一个词。然后将预测的词作为下一步解码器的输入。
# 3. **停止生成**：当生成 `<end>` 标记或达到最大长度时，停止生成。

# 我将修改代码，确保生成序列时使用 `<start>` 标记进行初始化，并通过逐步生成的词汇来构建输出序列。假设 `<start>` 和 `<end>` 标记在词汇表中分别对应索引 `0` 和 `1`。

### 修改后的代码

### 代码说明：

# 1. **初始化解码器输入**：
#    - 解码器的初始输入为 `<start>` 标记，它在词汇表中的索引为 `0`，用于生成第一个词。

# 2. **逐步生成序列**：
#    - 每次将当前生成的序列传入解码器，使用自回归方式生成下一个词。生成的词被作为下一步的输入，直到遇到 `<end>` 标记（索引为 `1`）或达到最大序列长度。

# 3. **序列生成终止**：
#    - 在 `generate_sequence` 函数中，判断是否生成了 `<end>` 标记。如果生成了 `<end>`，则提前停止生成过程。

# ### 运行结果：
# 1. **训练阶段**：模型通过 Teacher Forcing 学习如何预测序列中的下一个字符。
# 2. **测试阶段**：给定输入序列，模型自回归地生成输出序列，直到生成 `<end>` 标记或者达到最大长度。

# ### 总结：
# 这种方法通过 `<start>` 和 `<end>` 标记来控制序列生成的开始和结束，是标准的自回归 Transformer 语言模型生成方式。这种方法不仅适用于字符序列，还可以推广到其他序列生成任务，比如词汇生成、翻译等。

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 定义 Transformer 模型
class TransformerModel(nn.Module):
    def __init__(self, vocab_size, embed_size, n_heads, num_encoder_layers, num_decoder_layers, seq_len):
        super(TransformerModel, self).__init__()
        self.src_embedding = nn.Embedding(vocab_size, embed_size)
        self.tgt_embedding = nn.Embedding(vocab_size, embed_size)
        self.pos_encoder = PositionalEncoding(embed_size, max_len=seq_len)

        self.transformer = nn.Transformer(
            d_model=embed_size,
            nhead=n_heads,
            num_encoder_layers=num_encoder_layers,
            num_decoder_layers=num_decoder_layers
        )
        
        self.fc_out = nn.Linear(embed_size, vocab_size)
    
    def forward(self, src, tgt, tgt_mask=None):
        src = self.src_embedding(src) * np.sqrt(src.size(1))  # 缩放嵌入
        src = self.pos_encoder(src)

        tgt = self.tgt_embedding(tgt) * np.sqrt(tgt.size(1))
        tgt = self.pos_encoder(tgt)

        output = self.transformer(src, tgt, tgt_mask=tgt_mask)
        output = self.fc_out(output)
        return output

# 位置编码
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

# 创建简单的字符数据集
def create_char_data(vocab_size=10, seq_len=10, n_samples=1000):
    X = np.random.randint(2, vocab_size, (n_samples, seq_len))  # 随机生成字符序列，避免用到 <start> 和 <end>
    y = np.roll(X, -1, axis=1)  # 目标是预测序列中的下一个字符
    return X, y

# 生成 mask，用于自回归推理时遮挡未来词汇
def generate_square_subsequent_mask(sz):
    mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
    mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
    return mask

# 超参数设置
vocab_size = 12  # 词汇量大小 (包括 <start> = 0 和 <end> = 1)
seq_len = 10  # 序列长度
embed_size = 16
n_heads = 2
num_encoder_layers = 2
num_decoder_layers = 2
n_epochs = 100

# 生成数据
X, y = create_char_data(vocab_size=vocab_size, seq_len=seq_len, n_samples=1000)
X_train = torch.tensor(X[:800], dtype=torch.long)  # 训练集
y_train = torch.tensor(y[:800], dtype=torch.long)
X_test = torch.tensor(X[800:], dtype=torch.long)  # 测试集
y_test = torch.tensor(y[800:], dtype=torch.long)

# 定义模型、损失函数和优化器
model = TransformerModel(vocab_size=vocab_size, embed_size=embed_size, n_heads=n_heads,
                         num_encoder_layers=num_encoder_layers, num_decoder_layers=num_decoder_layers, seq_len=seq_len)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型（使用 Teacher Forcing）
for epoch in range(n_epochs):
    model.train()
    optimizer.zero_grad()

    tgt_input = y_train[:, :-1]  # 输入目标序列的前 n-1 个字符
    tgt_output = y_train[:, 1:]  # 目标是下一个字符
    tgt_mask = generate_square_subsequent_mask(tgt_input.size(1))

    output = model(X_train.permute(1, 0), tgt_input.permute(1, 0), tgt_mask).permute(1, 2, 0)  # (batch_size, vocab_size, seq_len)
    loss = criterion(output, tgt_output)

    loss.backward()
    optimizer.step()

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{n_epochs}], Loss: {loss.item():.4f}')

# 自回归推理（生成序列）
def generate_sequence(model, src, max_len=10):
    model.eval()
    src = src.unsqueeze(0)  # 添加批次维度
    generated_sequence = torch.tensor([[0]], dtype=torch.long)  # 初始化为 <start> 标记 (index 0)

    for i in range(max_len - 1):
        tgt_mask = generate_square_subsequent_mask(generated_sequence.size(1))

        with torch.no_grad():
            output = model(src.permute(1, 0), generated_sequence.permute(1, 0), tgt_mask).permute(1, 0, 2)
            next_token = output[:, -1, :].argmax(dim=-1)  # 取概率最大的词

        generated_sequence = torch.cat((generated_sequence, next_token.unsqueeze(1)), dim=1)

        # 如果生成 <end> 标记，停止生成
        if next_token.item() == 1:  # 1 表示 <end> 标记
            break

    return generated_sequence

# 测试阶段：自回归生成
src_test = X_test[0]  # 选取一个测试样本
generated_sequence = generate_sequence(model, src_test, max_len=seq_len)
print("\n输入序列：", src_test)
print("生成序列：", generated_sequence.squeeze(0))

