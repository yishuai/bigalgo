import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 示例性的基因序列数据
gene_sequences = [
    "ATCGATCG",
    "CGATCGAT",
    "GATCGATC",
    "TGCATGCA",
    "ATGCATGC"
]

# 将基因序列转换为数值编码
# A -> 0, C -> 1, G -> 2, T -> 3
char2idx = {'A': 0, 'C': 1, 'G': 2, 'T': 3}
idx2char = {0: 'A', 1: 'C', 2: 'G', 3: 'T'}

def encode_sequence(sequence):
    return [char2idx[char] for char in sequence]

def decode_sequence(encoded_sequence):
    return ''.join([idx2char[idx] for idx in encoded_sequence])

# 编码基因序列数据
encoded_sequences = [encode_sequence(seq) for seq in gene_sequences]

# 定义RNN模型
class RNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(RNN, self).__init__()
        self.hidden_size = hidden_size
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x, hidden):
        out, hidden = self.rnn(x, hidden)
        out = self.fc(out[:, -1, :])
        return out, hidden

# 将数据转换为PyTorch张量
input_tensor = torch.tensor(encoded_sequences, dtype=torch.float32).unsqueeze(1)  # 添加batch维度
target_tensor = torch.tensor([[1], [2], [3], [0], [1]], dtype=torch.long)

# 设置模型参数
input_size = 1  # 输入特征维度
hidden_size = 4  # 隐藏状态维度
output_size = 1  # 输出特征维度（与输入相同）

# 创建RNN模型实例
model = RNN(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.1)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    optimizer.zero_grad()
    hidden = torch.zeros(1, input_tensor.size(0), hidden_size)
    output, _ = model(input_tensor, hidden)
    loss = criterion(output, target_tensor.squeeze())
    loss.backward()
    optimizer.step()

    if (epoch+1) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 打印训练后的模型参数
print("RNN model parameters after training:")
for name, param in model.state_dict().items():
    print(name, param.shape)
    print(name, param.data)
