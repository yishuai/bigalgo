# Assignment 5 - Machine Learning!

  

## Part 3 - Written Questions

  

1.  **Question**: Explain your K-Means algorithm. What are the parts of your algorithm, and how do they work together to divide your samples into different clusters?

	**Answer**: *Your answer here*

------------------------------  

2.

- **Question**: What is each data point that is being divided into clusters? what does each cluster represent?

	 **Answer**: *Your answer here*

  

- **Question**: How does changing the number of clusters impact the result of the song dataset and the image compression dataset?

	**Answer**: *Your answer here*

------------------------------

3.

- **Question**: What is the difference between supervised classification, supervised regression, and unsupervised learning?

	**Answer**: *Your answer here*

- **Question**: Give an example of an algorithm under each, specifying the type of data that the algorithm takes in and the goal of the algorithm, and an explanation for why they are a supervised classification/supervised regression/unsupervised algorithm.

	**Answer**: *Your answer here*

------------------------------

4. **Question**: Give an overview of how you would modify your Kmeans class to implement Fair K-Means in  `kmeans.py`. Describe any methods you would add and where you would call them. You don’t need to understand the mathematical details of the Fair K-Means algorithm to have a general idea of the key changes necessary to modify your solution.

	**Answer**: *Your answer here*

------------------------------

5. **Question**:  How does the Fair K-means algorithm define fairness? Describe a situation or context where this definition of fairness might not be appropriate, or match your own perception of fairness.

	**Answer**: *Your answer here*

------------------------------

6. **Question**: Are there any situations in which even a perfectly fair ML system might still cause or even exacerbate harm? Are there other metrics or areas of social impact you might consider? Justify your opinion.

	**Answer**: *Your answer here*