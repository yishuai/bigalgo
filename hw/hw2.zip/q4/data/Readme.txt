The original data is from Chris Volinsky's website: http://www2.research.att.com/~volinsky/.
