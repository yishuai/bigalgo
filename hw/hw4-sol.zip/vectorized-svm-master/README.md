# vectorized-svm
Python implementation of vectorized Surport Vector Machine with Batch Gradient Descent, Stochastic Gradient Descent, and Mini-batch Gradient Descent. 
